import sun.java2d.loops.GeneralRenderer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class login implements ActionListener{



    private JFrame frame;
    private JPanel panel;
    private JButton button;
    private JTextField textFieldIP, textFieldName ;
    private JLabel labelMain, labelIP, labelName ;
    private String userName,ipAddress;


    //constructor for login

    public login(){

        GridBagLayout grid = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();

        panel = new JPanel(grid);
        panel.setBackground(Color.yellow);
        panel.setVisible(true);


        labelMain = new JLabel("LOGIN");

        textFieldIP = new JTextField();
        textFieldName = new JTextField();
        labelIP = new JLabel("IP Address");
        labelName = new JLabel("User Name");

        button = new JButton("SUBMIT");
        button.addActionListener(this);



        c.insets = new Insets(3,3,3,3);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 1;
        c.gridy = 0;
        c.gridwidth = 1 ;
        panel.add(labelMain,c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0 ;
        c.gridy = 1 ;
        c.gridwidth =1 ;
        panel.add(labelIP,c);

        c.gridx = GridBagConstraints.HORIZONTAL;
        c.gridx = 1;
        c.gridy = 1;
        c.gridwidth = 4;
        c.weightx =  0.1 ;
        //c.anchor = GridBagConstraints.LINE_END;

        panel.add(textFieldIP,c);

        c.gridx = GridBagConstraints.HORIZONTAL;
        c.gridx = 0 ;
        c.gridy = 2 ;
        c.gridwidth = 1 ;
        c.weightx =  0 ;
        c.ipadx = 0 ;
        panel.add(labelName,c);

        c.gridx = GridBagConstraints.HORIZONTAL;
        c.gridx = 1 ;
        c.gridy = 2 ;
        c.gridwidth = 4 ;
        c.weightx = 0.1 ;

        panel.add(textFieldName,c);

        c.gridx = GridBagConstraints.HORIZONTAL;
        c.gridx = 1 ;
        c.gridy = 3 ;
        c.gridwidth = 1 ;
        c.weightx = 0 ;
        c.ipadx =0 ;
        panel.add(button,c);

    }



    public String getUserName(){
        return this.userName ;
    }
    public String getIPAddress(){
        return this.ipAddress ;
    }

    public void actionPerformed (ActionEvent e){

        client client = new client();
        userName = textFieldName.getText();
        ipAddress = textFieldIP.getText();
        frame.dispose();

        client.setUserName(userName);
        client.setIPAddress(ipAddress);


        //client.go();


    }
    void build (){

        //server start = new server();
        //start.listenSocketServer();

        frame = new JFrame("Chat");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setSize(225,175);

        frame.add(BorderLayout.CENTER,panel);

    }
}
