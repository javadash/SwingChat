import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;


public class client implements ActionListener {



    private JButton buttonSend,buttonAttach ;
    private JTextField inputText;
    private JTextArea chatArea ;
    private JPanel panel,panel1 ;
    private JFrame frame ;
    private JLabel label;
    private Socket socket = null ;
    private PrintWriter out = null;
    private BufferedReader in = null;
    private String ip,name ;


    public client() {

        label = new JLabel("Chat Application");

        panel = new JPanel();

        panel.setVisible(true);
        panel.setBackground(Color.blue);
        //panel.setLayout(new GridBagLayout());
        //GridBagConstraints c = new GridBagConstraints();
        //c.insets = new Insets(10,10,10,10 );
        chatArea = new JTextArea(12,40);
        chatArea.setEditable(false);

        chatArea.setLineWrap(true);

        panel1 = new JPanel();

        panel1.setVisible(true);
        panel1.setBackground(Color.yellow);

        panel1.add(BorderLayout.NORTH,label);

        JScrollPane scroll = new JScrollPane(chatArea);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        panel1.add(BorderLayout.CENTER, scroll);


        buttonSend = new JButton("Send");
        buttonAttach = new JButton( "Attach");

        inputText = new JTextField(25);


        panel.add(inputText);

        panel.add(buttonAttach);
        AttachListener attach = new AttachListener();
        buttonAttach.addActionListener(attach);

        panel.add(buttonSend);
        //SendListener send = new SendListener();
        buttonSend.addActionListener(this);


    }



    public String setUserName(String n){
        return this.name = n  ;
    }
    public String setIPAddress(String i){
        return this.ip = i;
    }


    //public class SendListener implements ActionListener {

        public void actionPerformed (ActionEvent ev) {


            String lin = inputText.getText();

            out.println(lin);
            inputText.setText("");

            try {

                String l = in.readLine();
                chatArea.append(name +  " :" +l+"\n" );
                //System.out.println(l);


            } catch (IOException e) {
                System.out.println("Read failed.");
                System.exit(-1);
            }
        }
    //}
    //private PrintWriter out = null;
    //private BufferedReader in = null;

    public void listenSocketClient() {

        //Create socket connection
        try {
            socket = new Socket("192.168.1.7", server.getPort());


        } catch (IOException e) {
            e.printStackTrace();
        }

        //outputstream convert the data to send to a stream format
        //as a parameter write down where do you want to send it in getoutputstream constructor
        //send the stream to output port of the socket
       //OutputStreamWriter os = new OutputStreamWriter(socket.getOutputStream())

        //printwriter sends the data (stream)
        //send the data to os object which is output port of the socket
        try{
            //OutputStreamWriter os = new OutputStreamWriter(socket.getOutputStream());
            out = new PrintWriter(socket.getOutputStream(), true);

            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));


        }catch (IOException e){
            System.out.println("error");
        }



    }



    class AttachListener implements ActionListener{
        public void actionPerformed (ActionEvent ev){

        }
    }
    void go()  {

        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setSize(500,300);
        frame.add(BorderLayout.SOUTH,panel);
        frame.add(BorderLayout.CENTER,panel1);
        chatArea.setText(name+   " logged in.\n");

        //client cl = new client();
//        System.out.println(this.login.getUserName());
        //cl.listenSocketClient();
    }
    public static void  main(String [] arg){


        //login demo = new login() ;
        //demo.build();

        client cl = new client();
        cl.listenSocketClient();
        cl.go();





        //client start = new client();



    }


}
