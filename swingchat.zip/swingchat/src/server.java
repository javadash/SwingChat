import com.sun.corba.se.spi.activation.Server;
import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class server {
    private ServerSocket server = null;
    private Socket client = null;
    private BufferedReader in = null;
    private PrintWriter out = null;
    private String line;
    private client cl ;
    private static final int PORT = 10000;


    public static int getPort(){
        return PORT ;
    }

    public void listenSocketServer() {
        try {
            server = new ServerSocket(PORT);

        } catch (IOException e) {
            System.out.println("Could not listen on port "+ PORT);
            System.exit(-1);
        }

        try {
            client = server.accept();
            System.out.println("acc");

        } catch (IOException e) {
            System.out.println("Accept failed: "+ PORT);
            System.exit(-1);
        }

        try {
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));


            //System.out.println(s);
            out = new PrintWriter(client.getOutputStream(),true);




        } catch (IOException e) {
            System.out.println("Accept failed: "+PORT);
            System.exit(-1);
        }

        while (true){
            try{
                String s = in.readLine();
                out.println(s);


            }catch (IOException e ){
                System.out.println("Read Failed.");
                System.exit(-1);
            }
        }

    }



    public static   void main (String[] arg){

        server se = new server();
        se.listenSocketServer();

    }



}
