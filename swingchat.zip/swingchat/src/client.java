import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class client {

    private login login;

    private JButton button,button1 ;
    private JTextField inputText;
    private JTextArea chatArea ;
    private JPanel panel,panel1 ;
    private JFrame frame ;
    private JLabel label;

    public client(String user) {

        label = new JLabel("Chat Application");

        panel = new JPanel();

        panel.setVisible(true);
        panel.setBackground(Color.blue);
        //panel.setLayout(new GridBagLayout());
        //GridBagConstraints c = new GridBagConstraints();
        //c.insets = new Insets(10,10,10,10 );
        chatArea = new JTextArea(12,40);
        chatArea.setEditable(false);
        chatArea.setText(user +   " logged in.");
        chatArea.setLineWrap(true);

        panel1 = new JPanel();

        panel1.setVisible(true);
        panel1.setBackground(Color.yellow);

        panel1.add(BorderLayout.NORTH,label);

        JScrollPane scroll = new JScrollPane(chatArea);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        panel1.add(BorderLayout.CENTER, scroll);


        button = new JButton("Send");
        button1 = new JButton( "Attach");

        inputText = new JTextField(25);


        panel.add(inputText);
        panel.add(button1);
        panel.add(button);

    }

    void go(){

        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setSize(500,300);
        frame.add(BorderLayout.SOUTH,panel);
        frame.add(BorderLayout.CENTER,panel1);


   }




    class SendListener implements ActionListener {
        public void actionPerformed (ActionEvent ev){

        }
    }
    class AttachListener implements ActionListener{
        public void actionPerformed (ActionEvent ev){

        }
    }


}
